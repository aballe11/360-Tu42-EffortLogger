module EffortLoggerV2CSE360 {
	requires transitive javafx.graphics;
	requires javafx.controls;
	requires javafx.fxml;
	exports application.Prototype1;
	exports application.Prototype2;
	exports application.Prototype3;
	exports application.Prototype4;
	exports application.Prototype5;
	
	opens application to javafx.graphics, javafx.fxml;
	opens application.Prototype1 to javafx.graphics, javafx.fxml;
	
	//opens application.Prototype3 to javafx.fxml;
	opens application.Prototype3 to javafx.fxml;
}
